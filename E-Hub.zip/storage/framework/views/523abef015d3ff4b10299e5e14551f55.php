
<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
    <body>
        <link rel="stylesheet" href="css/main.css">
        <div class="container-sm">
        <h6>Topics</h6>
        <div class="accordion accordion-flush" id="accordionFlushExample">
            <div class="accordion-item">
              <h2 class="accordion-header">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
                  Accordion Item #1
                </button>
              </h2>
              <div id="flush-collapseOne" class="accordion-collapse collapse" data-bs-parent="#accordionFlushExample">
                <div class="accordion-body">
                    <ul>
                        <li>
                            <a href="button" class="link-dark">This is an example link</a>
                        </li>    
                        <li>
                            <a href="button" class="link-dark">This is an example link</a>
                        </li> 
                        <li>
                            <a href="button" class="link-dark">This is an example link</a>
                        </li> 
                        <li>
                            <a href="button" class="link-dark">This is an example link</a>
                        </li> 
                        <li>
                            <a href="button" class="link-dark">This is an example link</a>
                        </li>   
                    </ul>        
                </div>
              </div>
            </div>
            <div class="accordion-item">
              <h2 class="accordion-header">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo" aria-expanded="false" aria-controls="flush-collapseTwo">
                  Accordion Item #2
                </button>
              </h2>
              <div id="flush-collapseTwo" class="accordion-collapse collapse" data-bs-parent="#accordionFlushExample">
                <div class="accordion-body">
                    <ul>
                        <li>
                            <a href="button" class="link-dark">This is an example link</a>
                        </li>    
                        <li>
                            <a href="button" class="link-dark">This is an example link</a>
                        </li> 
                        <li>
                            <a href="button" class="link-dark">This is an example link</a>
                        </li> 
                        <li>
                            <a href="button" class="link-dark">This is an example link</a>
                        </li> 
                        <li>
                            <a href="button" class="link-dark">This is an example link</a>
                        </li>   
                </div>
              </div>
            </div>
            <div class="accordion-item">
              <h2 class="accordion-header">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseThree" aria-expanded="false" aria-controls="flush-collapseThree">
                  Accordion Item #3
                </button>
              </h2>
              <div id="flush-collapseThree" class="accordion-collapse collapse" data-bs-parent="#accordionFlushExample">
                <div class="accordion-body">
                    <ul>
                        <li>
                            <a href="button" class="link-dark">This is an example link</a>
                        </li>    
                        <li>
                            <a href="button" class="link-dark">This is an example link</a>
                        </li> 
                        <li>
                            <a href="button" class="link-dark">This is an example link</a>
                        </li> 
                        <li>
                            <a href="button" class="link-dark">This is an example link</a>
                        </li> 
                        <li>
                            <a href="button" class="link-dark">This is an example link</a>
                        </li>   
                </div>
              </div>
            </div>
            <div class="accordion-item">
                <h2 class="accordion-header">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseFour" aria-expanded="false" aria-controls="flush-collapseFour">
                    Accordion Item #4
                  </button>
                </h2>
                <div id="flush-collapseFour" class="accordion-collapse collapse" data-bs-parent="#accordionFlushExample">
                  <div class="accordion-body">
                    <ul>
                        <li>
                            <a href="button" class="link-dark">This is an example link</a>
                        </li>    
                        <li>
                            <a href="button" class="link-dark">This is an example link</a>
                        </li> 
                        <li>
                            <a href="button" class="link-dark">This is an example link</a>
                        </li> 
                        <li>
                            <a href="button" class="link-dark">This is an example link</a>
                        </li> 
                        <li>
                            <a href="button" class="link-dark">This is an example link</a>
                        </li>   
                  </div>
                </div>
              </div>
              <div class="accordion-item">
                <h2 class="accordion-header">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseFive" aria-expanded="false" aria-controls="flush-collapseFive">
                    Accordion Item #5
                  </button>
                </h2>
                <div id="flush-collapseFive" class="accordion-collapse collapse" data-bs-parent="#accordionFlushExample">
                  <div class="accordion-body">
                    <ul>
                        <li>
                            <a href="button" class="link-dark">This is an example link</a>
                        </li>    
                        <li>
                            <a href="button" class="link-dark">This is an example link</a>
                        </li> 
                        <li>
                            <a href="button" class="link-dark">This is an example link</a>
                        </li> 
                        <li>
                            <a href="button" class="link-dark">This is an example link</a>
                        </li> 
                        <li>
                            <a href="button" class="link-dark">This is an example link</a>
                        </li>   
                  </div>
                </div>
              </div>
              <div class="accordion-item">
                <h2 class="accordion-header">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseSix" aria-expanded="false" aria-controls="flush-collapseSix">
                    Accordion Item #6
                  </button>
                </h2>
                <div id="flush-collapseSix" class="accordion-collapse collapse" data-bs-parent="#accordionFlushExample">
                  <div class="accordion-body">
                    <ul>
                        <li>
                            <a href="button" class="link-dark">This is an example link</a>
                        </li>    
                        <li>
                            <a href="button" class="link-dark">This is an example link</a>
                        </li> 
                        <li>
                            <a href="button" class="link-dark">This is an example link</a>
                        </li> 
                        <li>
                            <a href="button" class="link-dark">This is an example link</a>
                        </li> 
                        <li>
                            <a href="button" class="link-dark">This is an example link</a>
                        </li>   
                  </div>
                </div>
              </div>
              <div class="accordion-item">
                <h2 class="accordion-header">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseSeven" aria-expanded="false" aria-controls="flush-collapseSeven">
                    Accordion Item #7
                  </button>
                </h2>
                <div id="flush-collapseSeven" class="accordion-collapse collapse" data-bs-parent="#accordionFlushExample">
                  <div class="accordion-body">
                    <ul>
                        <li>
                            <a href="button" class="link-dark">This is an example link</a>
                        </li>    
                        <li>
                            <a href="button" class="link-dark">This is an example link</a>
                        </li> 
                        <li>
                            <a href="button" class="link-dark">This is an example link</a>
                        </li> 
                        <li>
                            <a href="button" class="link-dark">This is an example link</a>
                        </li> 
                        <li>
                            <a href="button" class="link-dark">This is an example link</a>
                        </li>   
                  </div>
                </div>
              </div>
              <div class="accordion-item">
                <h2 class="accordion-header">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseEight" aria-expanded="false" aria-controls="flush-collapseEight">
                    Accordion Item #8
                  </button>
                </h2>
                <div id="flush-collapseEight" class="accordion-collapse collapse" data-bs-parent="#accordionFlushExample">
                  <div class="accordion-body">
                    <ul>
                        <li>
                            <a href="button" class="link-dark">This is an example link</a>
                        </li>    
                        <li>
                            <a href="button" class="link-dark">This is an example link</a>
                        </li> 
                        <li>
                            <a href="button" class="link-dark">This is an example link</a>
                        </li> 
                        <li>
                            <a href="button"class="link-dark">This is an example link</a>
                        </li> 
                        <li>
                            <a href="button" class="link-dark">This is an example link</a>
                        </li>   
                  </div>
                </div>
              </div>
              <div class="accordion-item">
                <h2 class="accordion-header">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseNine" aria-expanded="false" aria-controls="flush-collapseNine">
                    Accordion Item #9
                  </button>
                </h2>
                <div id="flush-collapseNine" class="accordion-collapse collapse" data-bs-parent="#accordionFlushExample">
                  <div class="accordion-body">
                    <ul>
                        <li>
                            <a href="button" class="link-dark">This is an example link</a>
                        </li>    
                        <li>
                            <a href="button" class="link-dark">This is an example link</a>
                        </li> 
                        <li>
                            <a href="button" class="link-dark">This is an example link</a>
                        </li> 
                        <li>
                            <a href="button" class="link-dark">This is an example link</a>
                        </li> 
                        <li>
                            <a href="button" class="link-dark">This is an example link</a>
                        </li>   
                  </div>
                </div>
              </div>
              <div class="accordion-item">
                <h2 class="accordion-header">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTen" aria-expanded="false" aria-controls="flush-collapseTen">
                    Accordion Item #10
                  </button>
                </h2>
                <div id="flush-collapseTen" class="accordion-collapse collapse" data-bs-parent="#accordionFlushExample">
                  <div class="accordion-body">
                    <ul>
                        <li>
                            <a href="button" class="link-dark">This is an example link</a>
                        </li>    
                        <li>
                            <a href="button" class="link-dark">This is an example link</a>
                        </li> 
                        <li>
                            <a href="button" class="link-dark">This is an example link</a>
                        </li> 
                        <li>
                            <a href="button" class="link-dark">This is an example link</a>
                        </li> 
                        <li>
                            <a href="button" class="link-dark">This is an example link</a>
                        </li>   
                  </div>
                </div>
              </div>
          </div>
        </div>
    </body> 
    <div class="bg-light py-3 sticky-bottom">
      <div class="container">
        <div class="row">
          <div class="col-md-6" >
            <p>&copy; 2021 My Company. All rights reserved.</p>
          </div>
          <div class="col-md-6 text-md-end">
            <a href="#">Privacy Policy</a>
            <span class="mx-2">|</span>
            <a href="#">Terms of Service</a>
          </div>
        </div>
      </div>
    </div>  
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CMS\resources\views/help.blade.php ENDPATH**/ ?>