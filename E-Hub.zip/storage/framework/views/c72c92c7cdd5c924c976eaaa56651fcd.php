
<?php $__env->startSection('bot'); ?>
<link rel="stylesheet" href="css/button.css">
    <div class="container-sm pt-5 pb-5">
        <div class="row">
            <div class="col-lg-9 border border-secondary rounded">
                    <h1>Sample</h1>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                      <hr>
                      <a href="#" class="link-dark bi bi-chat-left-text-fill"> Give feedback</a>
                      <hr>
                      <p>Was this helpful?<input class="btn btn-outline-secondary text-primary btn-lg" type="submit" value="Yes"> <input class="btn btn-outline-secondary text-primary btn-lg" type="submit" value="No"></p> 
            </div>
            <div class="col-lg-3">        
                <div class="list-group list-group-flush pt-5">

                    <a href="help" class="list-group-item list-group-item-action border border-0">Help</a>
                    
                    <a href="page2" class="list-group-item list-group-item-action bi bi-card-text border border-0"> Sample</a>
                    
                    <a href="button" class="list-group-item list-group-item-action bi bi-card-text border border-0"> Sample</a>
                    
                    <a href="page2" class="list-group-item list-group-item-action bi bi-card-text border border-0"> Sample</a>
                
                    <a href="button" class="list-group-item list-group-item-action bi bi-card-text border border-0"> Sample</a>

                    <a href="page2" class="list-group-item list-group-item-action bi bi-card-text border border-0"> Sample</a>
 
                    <a href="button" class="list-group-item list-group-item-action bi bi-card-text border border-0"> Sample</a>
                </div>
            </div> 
        </div> 
    </div>  
         

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CMS\resources\views/page2.blade.php ENDPATH**/ ?>