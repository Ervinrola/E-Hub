
<?php $__env->startSection('content'); ?>


<div class="album py-5 d-flex">
  <div class="container w-50 pl-1 lg-4">
    <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
      <div class="col">
        <div class="card shadow-sm">
          <a href="help">
            <div class="card-body">
            <i class="fa-solid fa-user fa-2xl p-4 position-absolute top-0 start-50 translate-middle-x"></i>
            <p class="card-text p-5">This is a sentence.</p>
            <div class="d-flex justify-content-between align-items-center">
            </div>
          </div>
          </a>
        </div>
      </div>  
      <div class="col">
        <div class="card shadow-sm">
          <a href="help">
          <div class="card-body">
            <i class="fa-solid fa-grid-2 fa-2xl p-4 position-absolute top-0 start-50 translate-middle-x"></i>
            <p class="card-text p-5">This is a sentence.</p>
            <div class="d-flex justify-content-between align-items-center">
            </div>  
          </div>
          </a>
        </div>
      </div>
      <div class="col">
        <div class="card shadow-sm">
          <a href="help">
          <div class="card-body">
            <i class="fa-solid fa-chart-simple fa-2xl p-4 position-absolute top-0 start-50 translate-middle-x"></i>
            <p class="card-text p-5">This is a sentence.</p>
            <div class="d-flex justify-content-between align-items-center">
            </div>
          </div>
          </a>
        </div>
      </div>
      <div class="col">
        <div class="card shadow-sm">
          <a href="help">
          <div class="card-body">
            <i class="fa-solid fa-files fa-2xl p-4 position-absolute top-0 start-50 translate-middle-x"></i>
            <p class="card-text p-5">This is a sentence.</p>
            <div class="d-flex justify-content-between align-items-center">
            </div>
          </div>
          </a>
        </div>
      </div>
      <div class="col">
        <div class="card shadow-sm">
          <a href="help">
          <div class="card-body">
            <i class="fa-solid fa-users-viewfinder fa-2xl p-4 position-absolute top-0 start-50 translate-middle-x"></i>
            <p class="card-text p-5">This is a sentence.</p>
            <div class="d-flex justify-content-between align-items-center">
            </div>
          </div>
          </a>
        </div>
      </div>
      <div class="col">
        <div class="card shadow-sm">
          <a href="help">
          <div class="card-body">
            <i class="fa-solid fa-cloud-question fa-2xl p-4 position-absolute top-0 start-50 translate-middle-x"></i>
            <p class="card-text p-5">This is a sentence.</p>
            <div class="d-flex justify-content-between align-items-center">
            </div>
          </div>
          </a>
        </div>
      </div>
  </div>
  </div>
 </div>

            <hr class="container border border-dark border-0 opacity-100 col-lg-8 d-flex">
            <div class="footer-top">
              <div class="container px-5 py-5 col-lg-8">
                <div class="row">
                  <div class="col-lg-4 col-md-6 footer-contact">
                    <div class="feature-icon bg-primary bg-gradient">
                      <svg class="bi" width="1em" height="1em"><use xlink:href="#collection"/></svg>
                    </div>
                    <h2>Sample</h2>
                    <p>Paragraph of text beneath the heading to explain the heading. We'll add onto it with another sentence and probably just keep going until we run out of words.</p>
                    <a href="#" class="icon-link">
                      Call to action
                      <svg class="bi" width="1em" height="1em"><use xlink:href="#chevron-right"/></svg>
                    </a>
                  </div>
                  <div class="col-lg-4 col-md-6 footer-links">
                    <div class="feature-icon bg-primary bg-gradient">
                      <svg class="bi" width="1em" height="1em"><use xlink:href="#people-circle"/></svg>
                    </div>
                    <h2>Sample</h2>
                    <p>Paragraph of text beneath the heading to explain the heading. We'll add onto it with another sentence and probably just keep going until we run out of words.</p>
                    <a href="#" class="icon-link">
                      Call to action
                      <svg class="bi" width="1em" height="1em"><use xlink:href="#chevron-right"/></svg>
                    </a>
                  </div>
                  <div class="col-lg-4 col-md-6 footer-links">
                    <div class="feature-icon bg-primary bg-gradient">
                      <svg class="bi" width="1em" height="1em"><use xlink:href="#toggles2"/></svg>
                    </div>
                    <h2>Sample</h2>
                    <p>Paragraph of text beneath the heading to explain the heading. We'll add onto it with another sentence and probably just keep going until we run out of words.</p>
                    <a href="#" class="icon-link">
                      Call to action
                      <svg class="bi" width="1em" height="1em"><use xlink:href="#chevron-right"/></svg>
                    </a>
                  </div>
                </div>
              </div>
              <footer>
                <hr class="container border border-secondary border-0 opacity-100 col-lg-8">
                <div class="footer-top">
                  <div class="container px-5 py-5 col-lg-8">
                    <div class="row">
                      <div class="col-lg-5 col-md-6 footer-contact">
                        <h3>SAMPLE</h3>
                        <p>
                          Sample Sample <br>
                          Sample Sample Sample <br>
                          Sample Sample  <br><br>
                          <strong>Phone:</strong> +0987654321 <br>
                          <strong>Email:</strong> info@example.com<br>
                        </p>
                      </div>
            
                      <div class="col-lg-4 col-md-6 footer-links">
                        <h4>Useful Links</h4>
                        <ul>
                          <li><i class="bx bx-chevron-right"></i> <a href="/">Home</a></li>
                          <li><i class="bx bx-chevron-right"></i> <a href="community">Community</a></li>
                          <li><i class="bx bx-chevron-right"></i> <a href="help">Help Center</a></li>
                          <li><i class="bx bx-chevron-right"></i> <a href="about">About us</a></li>
                        </ul>
                      </div>
            
                      <div class="col-lg-3 col-md-6 footer-links">
                        <h4>Our Services</h4>
                        <ul>
                          <li><i class="bx bx-chevron-right"></i> <a href="#">Web Design</a></li>
                          <li><i class="bx bx-chevron-right"></i> <a href="#">Web Development</a></li>
                          <li><i class="bx bx-chevron-right"></i> <a href="#">Product Management</a></li>
                          <li><i class="bx bx-chevron-right"></i> <a href="#">Marketing</a></li>
                          <li><i class="bx bx-chevron-right"></i> <a href="#">Graphic Design</a></li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
                <br>
                <div class="d-flex bg-light py-3 sticky-bottom">
                  <div class="container">
                    <div class="row">
                      <div class="col-md-6" >
                        <p>&copy; 2021 My Company. All rights reserved.</p>
                      </div>
                      <div class="col-md-6 text-md-end">
                        <a href="#">Privacy Policy</a>
                        <span class="mx-2">|</span>
                        <a href="#">Terms of Service</a>
                      </div>
                    </div>
                  </div>
                </div>
              </footer>
              <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
              <script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js"></script>
              <script src="https://pingendo.com/assets/bootstrap/bootstrap-4.0.0-alpha.6.min.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CMS\resources\views/home.blade.php ENDPATH**/ ?>