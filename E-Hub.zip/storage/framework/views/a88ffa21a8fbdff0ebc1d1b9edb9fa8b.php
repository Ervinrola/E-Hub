<?php $__env->startSection('admin'); ?>
    <link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
    <div class="row d-flex">
        <div class="pt-4 col-md-6 col-lg-8 flex-grow-2">
            <div class="card text-left w-75" style="margin-left: 25%;">
                <div class="card-header">
                    <div class="pb-3">
                        <h5 class="modal-title" id="staticBackdropLabel">Create a post</h5>
                    </div>
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active text-dark" id="home-tab" data-bs-toggle="tab"
                                data-bs-target="#home" type="button" role="tab" aria-controls="home"
                                aria-selected="true"><i class="fa-solid fa-file"></i> Post</button>
                        </li>
                    </ul>
                    <br>
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                            <input class="form-control form-control-lg" type="text" placeholder="Title"
                                aria-label=".form-control-lg example" required>
                                
                            <br>
                            <div class="drop-zone text-center">
                                <span class="drop-zone__prompt p-5">Drag & Drop a file here or click to select one</span>
                                <input type="file" name="file" id="file" class="drop-zone__input">
                            </div>
                            <br>
                            <textarea id="editor" style="height: 20rem; width: 100%;" class="bg-white" required></textarea>
                            <!-- Include the Quill library -->
                            <script src="https://cdn.quilljs.com/1.3.6/quill.js"></script>

                            <!-- Initialize Quill editor -->
                            <script>
                                var quill = new Quill('#editor', {
                                    theme: 'snow'
                                });
                            </script>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="button" class="btn btn-primary">Post</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="pt-5 col-sm-12 col-md-3 col-lg-3">
            <h4>Recent Post</h4>

            <?php for($i = 0; $i < 2; $i++): ?>
                <div class="card mt-4">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <img class="card-img-top img-responsive"
                            src="https://static.remove.bg/sample-gallery/graphics/fish-thumbnail.jpg" alt="Title" style="width: 100px; height: 70px;">
                            <div class="d-flex flex-column mx-2">
                                <h4 class="card-title pt-3">Title</h4>
                                <p>April 11, 2023 <a href="#"> Admin</a></p>
                            </div>
                        </div>

                        <small class="text-success">1 hour ago</small>
                        <p class="text-dark">It is a long established fact that a reader will be distracted by the readable
                            content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a
                            more-or-less norm...</p>

                        <button type="button" class="btn btn-danger mt-2">Delete</button>
                    </div>
                </div>
            <?php endfor; ?>
        </div>
        <footer>
            <div class="bg-light py-3 sticky-bottom mt-5">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6">
                            <p>&copy; 2021 My Company. All rights reserved.</p>
                        </div>
                        <div class="col-md-6 text-md-end">
                            <a href="#">Privacy Policy</a>
                            <span class="mx-2">|</span>
                            <a href="#">Terms of Service</a>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-Hub\resources\views/publish.blade.php ENDPATH**/ ?>