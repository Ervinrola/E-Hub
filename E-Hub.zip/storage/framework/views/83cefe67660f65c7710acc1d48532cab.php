
<?php $__env->startSection('bot'); ?>
<br> <br>
<section id="about-us" class="py-5">
    <div class="container">
      <div class="row">
        <div class="col-lg-6">
          <img src="https://via.placeholder.com/600x400" class="img-fluid rounded" alt="About Us Image">
        </div>
        <div class="col-lg-6">
          <h2>About Us</h2>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed quis justo euismod, volutpat tellus in, dictum velit. Suspendisse convallis vestibulum dui, id dictum dolor lacinia eget. Nunc rhoncus bibendum enim, sit amet facilisis justo molestie a. Integer vel tristique magna. Donec eget elit tortor. Sed auctor nisl quis elit tincidunt ullamcorper. Fusce fringilla sapien vitae ligula laoreet blandit.</p>
          <p>Sed a neque vel odio sollicitudin tempor eu eu ipsum. Aliquam tristique commodo mi, vel laoreet nisl euismod eget. In hac habitasse platea dictumst. Vivamus consequat, lectus sit amet malesuada feugiat, arcu felis iaculis velit, vitae fermentum nulla ex in ipsum.</p>
          <a href="#" class="btn btn-primary">Learn More</a>
        </div>
      </div>
    </div>
  </section>  
  <section id="about-us" class="py-5">
    <div class="container">
      <div class="row">
        <div class="col-lg-6">
          <img src="https://via.placeholder.com/600x400" class="img-fluid rounded" alt="About Us Image">
        </div>
        <div class="col-lg-6">
          <h2>Contact Information</h2>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed quis justo euismod, volutpat tellus in, dictum velit. Suspendisse convallis vestibulum dui, id dictum dolor lacinia eget. Nunc rhoncus bibendum enim, sit amet facilisis justo molestie a. Integer vel tristique magna. Donec eget elit tortor. Sed auctor nisl quis elit tincidunt ullamcorper. Fusce fringilla sapien vitae ligula laoreet blandit.</p>
          <p>Sed a neque vel odio sollicitudin tempor eu eu ipsum. Aliquam tristique commodo mi, vel laoreet nisl euismod eget. In hac habitasse platea dictumst. Vivamus consequat, lectus sit amet malesuada feugiat, arcu felis iaculis velit, vitae fermentum nulla ex in ipsum.</p>
          <a href="#" class="btn btn-primary">Learn More</a>
        </div>
      </div>
    </div>
  </section>  
          <div class="d-flex bg-light py-3 sticky-bottom">
          <div class="container">
            <div class="row">
              <div class="col-md-6" >
                <p>&copy; 2021 My Company. All rights reserved.</p>
              </div>
              <div class="col-md-6 text-md-end">
                <a href="#">Privacy Policy</a>
                <span class="mx-2">|</span>
                <a href="#">Terms of Service</a>
              </div>
            </div>
          </div>
        </div>
<?php $__env->stopSection(); ?>

  
<?php echo $__env->make('layout.master1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CMS\resources\views/about.blade.php ENDPATH**/ ?>