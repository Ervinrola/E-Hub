
<?php $__env->startSection('bot'); ?>

  <div class="d-flex align-items-start p-5 m-5">
    <div class="nav flex-column nav-pills me-3 p-5 m-5" id="v-pills-tab" role="tablist" aria-orientation="vertical">
      <button class="nav-link active" id="v-pills-home-tab" data-bs-toggle="pill" data-bs-target="#v-pills-home" type="button" role="tab" aria-controls="v-pills-home" aria-selected="true">Home</button>
      <button class="nav-link" id="v-pills-profile-tab" data-bs-toggle="pill" data-bs-target="#v-pills-profile" type="button" role="tab" aria-controls="v-pills-profile" aria-selected="false">Sample</button>
      <button class="nav-link" id="v-pills-messages-tab" data-bs-toggle="pill" data-bs-target="#v-pills-messages" type="button" role="tab" aria-controls="v-pills-messages" aria-selected="false">Sample</button>
      <button class="nav-link" id="v-pills-settings-tab" data-bs-toggle="pill" data-bs-target="#v-pills-settings" type="button" role="tab" aria-controls="v-pills-settings" aria-selected="false">Sample</button>
    </div>
    <div class="tab-content p-5 m-5" id="v-pills-tabContent">
      <div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
        <h3>Sample</h3>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed quis justo euismod, volutpat tellus in, dictum velit. Suspendisse convallis vestibulum dui, id dictum dolor lacinia eget. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed quis justo euismod, volutpat tellus in, dictum velit. Suspendisse convallis vestibulum dui, id dictum dolor lacinia eget. Nunc rhoncus bibendum enim, sit amet facilisis justo molestie a. Integer vel tristique magna. Donec eget elit tortor. Sed auctor nisl quis elit tincidunt ullamcorper. Fusce fringilla sapien vitae ligula laoreet blandit. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed quis justo euismod, volutpat tellus in, dictum velit. Suspendisse convallis vestibulum dui, id dictum dolor lacinia eget. Nunc rhoncus bibendum enim, sit amet facilisis justo molestie a. Integer vel tristique magna. Donec eget elit tortor. Sed auctor nisl quis elit tincidunt ullamcorper. Fusce fringilla sapien vitae ligula laoreet blandit.</p>
              <ul>
                <li>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                </li>
                <li>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                </li>
                <li>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                </li>
              </ul>
      </div>
      <div class="tab-pane fade" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab">
        <h3>Sample</h3>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed quis justo euismod, volutpat tellus in, dictum velit. Suspendisse convallis vestibulum dui, id dictum dolor lacinia eget. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed quis justo euismod, volutpat tellus in, dictum velit. Suspendisse convallis vestibulum dui, id dictum dolor lacinia eget. Nunc rhoncus bibendum enim, sit amet facilisis justo molestie a. Integer vel tristique magna. Donec eget elit tortor. Sed auctor nisl quis elit tincidunt ullamcorper. Fusce fringilla sapien vitae ligula laoreet blandit. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed quis justo euismod, volutpat tellus in, dictum velit. Suspendisse convallis vestibulum dui, id dictum dolor lacinia eget. Nunc rhoncus bibendum enim, sit amet facilisis justo molestie a. Integer vel tristique magna. Donec eget elit tortor. Sed auctor nisl quis elit tincidunt ullamcorper. Fusce fringilla sapien vitae ligula laoreet blandit.</p>
      </div>
      <div class="tab-pane fade" id="v-pills-messages" role="tabpanel" aria-labelledby="v-pills-messages-tab">
        <h3>Sample</h3>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed quis justo euismod, volutpat tellus in, dictum velit. Suspendisse convallis vestibulum dui, id dictum dolor lacinia eget. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed quis justo euismod, volutpat tellus in, dictum velit. Suspendisse convallis vestibulum dui, id dictum dolor lacinia eget. Nunc rhoncus bibendum enim, sit amet facilisis justo molestie a. Integer vel tristique magna. Donec eget elit tortor. Sed auctor nisl quis elit tincidunt ullamcorper. Fusce fringilla sapien vitae ligula laoreet blandit. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed quis justo euismod, volutpat tellus in, dictum velit. Suspendisse convallis vestibulum dui, id dictum dolor lacinia eget. Nunc rhoncus bibendum enim, sit amet facilisis justo molestie a. Integer vel tristique magna. Donec eget elit tortor. Sed auctor nisl quis elit tincidunt ullamcorper. Fusce fringilla sapien vitae ligula laoreet blandit.</p>
      </div>
      <div class="tab-pane fade" id="v-pills-settings" role="tabpanel" aria-labelledby="v-pills-settings-tab">
        <h3>Sample</h3>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed quis justo euismod, volutpat tellus in, dictum velit. Suspendisse convallis vestibulum dui, id dictum dolor lacinia eget. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed quis justo euismod, volutpat tellus in, dictum velit. Suspendisse convallis vestibulum dui, id dictum dolor lacinia eget. Nunc rhoncus bibendum enim, sit amet facilisis justo molestie a. Integer vel tristique magna. Donec eget elit tortor. Sed auctor nisl quis elit tincidunt ullamcorper. Fusce fringilla sapien vitae ligula laoreet blandit. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed quis justo euismod, volutpat tellus in, dictum velit. Suspendisse convallis vestibulum dui, id dictum dolor lacinia eget. Nunc rhoncus bibendum enim, sit amet facilisis justo molestie a. Integer vel tristique magna. Donec eget elit tortor. Sed auctor nisl quis elit tincidunt ullamcorper. Fusce fringilla sapien vitae ligula laoreet blandit.</p>
              <ul>
                <li>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                </li>
                <li>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                </li>
                <li>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                </li>
              </ul>
      </div>
    </div>
  </div>
        <div class="d-flex bg-light py-3 sticky-bottom">
          <div class="container">
            <div class="row">
              <div class="col-md-6" >
                <p>&copy; 2021 My Company. All rights reserved.</p>
              </div>
              <div class="col-md-6 text-md-end">
                <a href="#">Privacy Policy</a>
                <span class="mx-2">|</span>
                <a href="#">Terms of Service</a>
              </div>
            </div>
          </div>
        </div>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CMS\resources\views/community.blade.php ENDPATH**/ ?>