<?php $__env->startSection('admin'); ?>
    <div class="container">
        <h1 class="mt-5">My Profile</h1>
        <div class="card text-start shadow-lg border border-none">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <div class="d-flex align-items-center">
                            <img src="https://avatarairlines.com/wp-content/uploads/2020/05/Male-placeholder.jpeg"
                                alt="" class="rounded-circle" width="100" height="100">
                            <div class="d-flex flex-column ms-5">
                                <h5>Joshua Lopez</h5>
                                <p>Team Manager</p>
                                <p class="text-muted">Malanday, Marikina City</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="d-flex justify-content-end mt-5">
                            <button class="btn btn btn-outline btn-outline-solid btn-outline-secondary btn-sm rounded-pill"
                                data-bs-toggle="modal" data-bs-target="#editModal">Edit<i
                                    class="fa fa-pen ms-3"></i></button>
                        </div>
                    </div>

                    <!-- Modal -->
                    <div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel"
                        aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="editModalLabel">Profile</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <style>
                                    body {
                                        margin-top: 20px;
                                    }

                                    .avatar {
                                        width: 200px;
                                        height: 200px;
                                    }
                                </style>
                                <div class="modal-body">
                                    <!-- Add your form or content for editing here -->
                                    <h3>Profile Edit</h3>
                                    <form class="form-horizontal" role="form">
                                        <div class="form-group">
                                            <label class="col-lg-3 control-label mt-3">First name:</label>
                                            <div class="col-lg-8  mt-3">
                                                <input class="form-control" type="text" value="dey-dey">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-3 control-label mt-3">Last name:</label>
                                            <div class="col-lg-8  mt-3">
                                                <input class="form-control" type="text" value="bootdey">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-3 control-label mt-3">Position:</label>
                                            <div class="col-lg-8  mt-3">
                                                <input class="form-control" type="text" value="">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-3 control-label mt-3">Address:</label>
                                            <div class="col-lg-8  mt-3">
                                                <input class="form-control" type="text" value="janesemail@gmail.com">
                                            </div>
                                        </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                    <button type="button" class="btn btn-primary">Save changes</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card text-start shadow-lg border border-none">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4 ">
                        <div class="d-flex align-items-center">
                            <div class="d-flex flex-column ms-5">
                                <h5>Personal Information</h5>
                                <p class="text-muted mt-3 mb-2">First Name</p>
                                <p>Name</p>
                                <p class="text-muted mt-3 mb-2">Email Address</p>
                                <p>johnervinenglesrola@email.com</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 ">
                        <div class="d-flex align-items-center">
                            <div class="d-flex flex-column ms-5 mt-4 py-2">

                                <p class="text-muted mt-3 mb-2">Last Name</p>
                                <p>Name</p>
                                <p class="text-muted mt-3 mb-2">Phone</p>
                                <p>+09 876 543 210</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="d-flex justify-content-end mt-5 pt-5">
                            <button class="btn btn btn-outline btn-outline-solid btn-outline-secondary btn-sm rounded-pill"
                                data-bs-toggle="modal" data-bs-target="#editModal">Edit<i
                                    class="fa fa-pen ms-3"></i></button>
                        </div>
                    </div>

                    <!-- Modal -->
                    <div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel"
                        aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="editModalLabel">Profile</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <style>
                                    body {
                                        margin-top: 20px;
                                    }

                                    .avatar {
                                        width: 200px;
                                        height: 200px;
                                    }
                                </style>
                                <div class="modal-body">
                                    <!-- Add your form or content for editing here -->
                                    <h3>Profile Edit</h3>
                                    <form class="form-horizontal" role="form">
                                        <div class="form-group">
                                            <label class="col-lg-3 control-label mt-3">First name:</label>
                                            <div class="col-lg-8  mt-3">
                                                <input class="form-control" type="text" value="dey-dey">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-3 control-label mt-3">Last name:</label>
                                            <div class="col-lg-8  mt-3">
                                                <input class="form-control" type="text" value="bootdey">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-3 control-label mt-3">Position:</label>
                                            <div class="col-lg-8  mt-3">
                                                <input class="form-control" type="text" value="">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-3 control-label mt-3">Address:</label>
                                            <div class="col-lg-8  mt-3">
                                                <input class="form-control" type="text" value="janesemail@gmail.com">
                                            </div>
                                        </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                    <button type="button" class="btn btn-primary">Save changes</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-Hub\resources\views/profile.blade.php ENDPATH**/ ?>