<link href="css/button.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<link href="/docs/5.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">



<section class="vh-100">
    <div class="container py-5 h-100">
        <div class="col-md-5 col-lg-6 col-xl-3 text-center">

        </div>
        <div class="row d-flex justify-content-center align-items-center h-100">

            <div class="col-12 col-md-8 col-lg-6 col-xl-5 text-center">

                <img src="https://depedmarikina.ph/photos/sdo_logo.png" class="img-fluid" alt="Sample image"
                    style="width: 150px;">

                <form action="admin" method="get">
                    <div class="card shadow-2-strong" style="border-radius: 1rem;">
                        <div class="card-body p-5">

                            <h3 class="mb-5">Sign in</h3>

                            <div class="form-outline mb-4">
                                <input type="email" id="typeEmailX-2" class="form-control form-control-lg"
                                    placeholder="Enter Email" required />
                            </div>

                            <!-- Password -->
                            <div class="form-outline mb-3">
                                <div class="input-group">
                                    <input type="password" id="password" class="form-control form-control-lg"
                                        placeholder="Enter Password" required />
                                    <button type="button" class="btn btn-outline-secondary" id="show-password-btn"
                                        onclick="togglePasswordVisibility()">Show</button>
                                </div>
                            </div>

                            <!-- Checkbox -->
                            <div class="form-check d-flex justify-content-start mb-4">
                                <input class="form-check-input" type="checkbox" value="" id="form1Example3" />
                                <label class="form-check-label px-4" for="form1Example3"> Remember password</label>
                                <div class="col">
                                    <!-- Simple link -->
                                    <a href="#!" class="ml-2">Forgot password?</a>
                                </div>
                            </div>

                            <button class="btn btn-primary btn-lg btn-block w-100" type="submit">Login</button>

                            <div class="divider d-flex align-items-center my-4">
                                <p class="text-center mx-3 mb-0">or</p>
                            </div>

                            <button type="button" class="login-with-google-btn w-100"><a
                                    href="https://accounts.google.com/InteractiveLogin/signinchooser?continue=https%3A%2F%2Faccounts.google.com%2F&followup=https%3A%2F%2Faccounts.google.com%2F&passive=1209600&ifkv=AQMjQ7TbsFqyIeIp1fgWjCJ14EjqGc0E22Glr1h0N4
MkWD_R_8JMBX3LnWVnUGr7hEmk34SLgg1t&flowName=GlifWebSignIn&flowEntry=ServiceLogin"
                                    class="text-decoration-none" style="color: #757575;">
                                    Sign in with Google
                                </a>
                            </button>
                        </div>
                    </div>
            </div>
        </div>
    </div>
    </form>
    <script src="script/js.js"></script>
</section>
<?php /**PATH C:\xampp\htdocs\E-Hub\resources\views/login.blade.php ENDPATH**/ ?>