@extends('layout.master1')
@section('bot')
    <style>
        .star-rating {
            display: inline-block;
            font-size: 1em;
            color: gold;
        }

        .star {
            cursor: pointer;
        }
    </style>

    <div class="container-fluid col-md-6 pt-5 ">
        <div class="border-start border-5 border-primary">
            <p class="px-3 fs-5 mb-5">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                incididunt ut
                labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut
                aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum
                dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia
                deserunt mollit anim id est laborum.</p>
        </div>
        <h1 class="text-secondary"><i class="fa-sharp fa-solid fa-book fa-lg mx-2 bg-primary"></i>Title of the article</h1>
        <div class="border-bottom border-primary border-3" style="width: 400px;">
        </div>
        <button type="button" class="btn btn-white" data-bs-toggle="tooltip" data-bs-placement="bottom"
            title="Tooltip on bottom"><i class="fa-sharp fa-regular fa-folder-open fa-xs"></i>
            Posts
        </button>
        <button type="button" class="btn btn-white" data-bs-toggle="tooltip" data-bs-placement="bottom"
            title="Tooltip on bottom"><i class="fa-sharp fa-solid fa-calendar-days fa-xs"></i>
            April 14 2023
        </button>
        Rating:
        <div class="star-rating">
            <span class="star" onclick="setRating(1)">★</span>
            <span class="star" onclick="setRating(2)">★</span>
            <span class="star" onclick="setRating(3)">★</span>
            <span class="star" onclick="setRating(4)">★</span>
            <span class="star" onclick="setRating(5)">★</span>
        </div>
        <p class="pt-5">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
    </div>
    </div>

    <script>
        function setRating(rating) {
            // Remove active class from all stars
            const stars = document.querySelectorAll(".star-rating .star");
            stars.forEach((star) => {
                star.classList.remove("active");
            });

            // Add active class to selected stars
            for (let i = 0; i < rating; i++) {
                stars[i].classList.add("active");
            }
        }
    </script>
@endsection
