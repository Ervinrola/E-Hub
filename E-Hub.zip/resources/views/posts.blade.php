@extends('layout.admin')
@section('admin')
    <link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@yaireo/tagify@4.3.0/dist/tagify.css">
    <div class="row d-flex">
        <div class="pt-4 col-md-6 col-lg-8 flex-grow-2">
            <div class="card text-left w-75" style="margin-left: 25%;">
                <div class="card-header bg-white shadow">
                    <div class="pb-3">
                        <h5 class="modal-title" id="staticBackdropLabel">Create a post</h5>
                    </div>
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active text-dark" id="home-tab" data-bs-toggle="tab"
                                data-bs-target="#home" type="button" role="tab" aria-controls="home"
                                aria-selected="true"><i class="fa-solid fa-file"></i> Post</button>
                        </li>
                    </ul>

                    <div class="tab-content bg-white" id="myTabContent">
                        <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                            <div class="container-fluid pb-3">
                                <div class="row pt-3">
                                    <div class="col-sm-12 col-md-7 col-lg-4">
                                        <h4 class="pt-2 text-secondary">Caption</h4>
                                    </div>
                                    <div class="col-sm-12 col-md-7 col-lg-8 ">
                                        <input class="form-control form-control-lg mb-3" type="text" placeholder=""
                                            aria-label=".form-control-lg example" required>
                                    </div>
                                </div>


                                <div id="editor">
                                </div>

                                <script src="https://cdn.ckeditor.com/ckeditor5/37.0.1/super-build/ckeditor.js"></script>
                                <!--
                                                                        Uncomment to load the Spanish translation
                                                                        <script src="https://cdn.ckeditor.com/ckeditor5/37.0.1/super-build/translations/es.js"></script>
                                                                    -->
                                <script>
                                    // This sample still does not showcase all CKEditor 5 features (!)
                                    // Visit https://ckeditor.com/docs/ckeditor5/latest/features/index.html to browse all the features.
                                    CKEDITOR.ClassicEditor.create(document.getElementById("editor"), {
                                        // https://ckeditor.com/docs/ckeditor5/latest/features/toolbar/toolbar.html#extended-toolbar-configuration-format
                                        toolbar: {
                                            items: [
                                                'exportPDF', 'exportWord', '|',
                                                'findAndReplace', 'selectAll', '|',
                                                'heading', '|',
                                                'bold', 'italic', 'strikethrough', 'underline', 'subscript', 'superscript',
                                                'removeFormat', '|',
                                                'bulletedList', 'numberedList', 'todoList', '|',
                                                'outdent', 'indent', '|',
                                                'undo', 'redo',
                                                '-',
                                                'fontSize', 'fontFamily', 'fontColor', 'fontBackgroundColor', 'highlight', '|',
                                                'alignment', '|',
                                                'link', 'insertImage', 'blockQuote', 'insertTable', 'mediaEmbed',
                                                '|',
                                                'specialCharacters', 'horizontalLine', 'pageBreak', '|',
                                                '|',

                                            ],
                                            shouldNotGroupWhenFull: true
                                        },
                                        // Changing the language of the interface requires loading the language file using the <script> tag.
                                        // language: 'es',
                                        list: {
                                            properties: {
                                                styles: true,
                                                startIndex: true,
                                                reversed: true
                                            }
                                        },
                                        // https://ckeditor.com/docs/ckeditor5/latest/features/headings.html#configuration
                                        heading: {
                                            options: [{
                                                    model: 'paragraph',
                                                    title: 'Paragraph',
                                                    class: 'ck-heading_paragraph'
                                                },
                                                {
                                                    model: 'heading1',
                                                    view: 'h1',
                                                    title: 'Heading 1',
                                                    class: 'ck-heading_heading1'
                                                },
                                                {
                                                    model: 'heading2',
                                                    view: 'h2',
                                                    title: 'Heading 2',
                                                    class: 'ck-heading_heading2'
                                                },
                                                {
                                                    model: 'heading3',
                                                    view: 'h3',
                                                    title: 'Heading 3',
                                                    class: 'ck-heading_heading3'
                                                },
                                                {
                                                    model: 'heading4',
                                                    view: 'h4',
                                                    title: 'Heading 4',
                                                    class: 'ck-heading_heading4'
                                                },
                                                {
                                                    model: 'heading5',
                                                    view: 'h5',
                                                    title: 'Heading 5',
                                                    class: 'ck-heading_heading5'
                                                },
                                                {
                                                    model: 'heading6',
                                                    view: 'h6',
                                                    title: 'Heading 6',
                                                    class: 'ck-heading_heading6'
                                                }
                                            ]
                                        },
                                        // https://ckeditor.com/docs/ckeditor5/latest/features/editor-placeholder.html#using-the-editor-configuration
                                        placeholder: 'Enter your content here...',
                                        // https://ckeditor.com/docs/ckeditor5/latest/features/font.html#configuring-the-font-family-feature
                                        fontFamily: {
                                            options: [
                                                'default',
                                                'Arial, Helvetica, sans-serif',
                                                'Courier New, Courier, monospace',
                                                'Georgia, serif',
                                                'Lucida Sans Unicode, Lucida Grande, sans-serif',
                                                'Tahoma, Geneva, sans-serif',
                                                'Times New Roman, Times, serif',
                                                'Trebuchet MS, Helvetica, sans-serif',
                                                'Verdana, Geneva, sans-serif'
                                            ],
                                            supportAllValues: true
                                        },
                                        // https://ckeditor.com/docs/ckeditor5/latest/features/font.html#configuring-the-font-size-feature
                                        fontSize: {
                                            options: [10, 12, 14, 'default', 18, 20, 22],
                                            supportAllValues: true
                                        },
                                        // Be careful with the setting below. It instructs CKEditor to accept ALL HTML markup.
                                        // https://ckeditor.com/docs/ckeditor5/latest/features/general-html-support.html#enabling-all-html-features
                                        htmlSupport: {
                                            allow: [{
                                                name: /.*/,
                                                attributes: true,
                                                classes: true,
                                                styles: true
                                            }]
                                        },
                                        // Be careful with enabling previews
                                        // https://ckeditor.com/docs/ckeditor5/latest/features/html-embed.html#content-previews
                                        htmlEmbed: {
                                            showPreviews: true
                                        },
                                        // https://ckeditor.com/docs/ckeditor5/latest/features/link.html#custom-link-attributes-decorators
                                        link: {
                                            decorators: {
                                                addTargetToExternalLinks: true,
                                                defaultProtocol: 'https://',
                                                toggleDownloadable: {
                                                    mode: 'manual',
                                                    label: 'Downloadable',
                                                    attributes: {
                                                        download: 'file'
                                                    }
                                                }
                                            }
                                        },
                                        // https://ckeditor.com/docs/ckeditor5/latest/features/mentions.html#configuration
                                        mention: {
                                            feeds: [{
                                                marker: '@',
                                                feed: [
                                                    '@apple', '@bears', '@brownie', '@cake', '@cake', '@candy', '@canes',
                                                    '@chocolate', '@cookie', '@cotton', '@cream',
                                                    '@cupcake', '@danish', '@donut', '@dragée', '@fruitcake', '@gingerbread',
                                                    '@gummi', '@ice', '@jelly-o',
                                                    '@liquorice', '@macaroon', '@marzipan', '@oat', '@pie', '@plum', '@pudding',
                                                    '@sesame', '@snaps', '@soufflé',
                                                    '@sugar', '@sweet', '@topping', '@wafer'
                                                ],
                                                minimumCharacters: 1
                                            }]
                                        },
                                        // The "super-build" contains more premium features that require additional configuration, disable them below.
                                        // Do not turn them on unless you read the documentation and know how to configure them and setup the editor.
                                        removePlugins: [
                                            // These two are commercial, but you can try them out without registering to a trial.
                                            // 'ExportPdf',
                                            // 'ExportWord',
                                            'CKBox',
                                            'CKFinder',
                                            'EasyImage',
                                            // This sample uses the Base64UploadAdapter to handle image uploads as it requires no configuration.
                                            // https://ckeditor.com/docs/ckeditor5/latest/features/images/image-upload/base64-upload-adapter.html
                                            // Storing images as Base64 is usually a very bad idea.
                                            // Replace it on production website with other solutions:
                                            // https://ckeditor.com/docs/ckeditor5/latest/features/images/image-upload/image-upload.html
                                            // 'Base64UploadAdapter',
                                            'RealTimeCollaborativeComments',
                                            'RealTimeCollaborativeTrackChanges',
                                            'RealTimeCollaborativeRevisionHistory',
                                            'PresenceList',
                                            'Comments',
                                            'TrackChanges',
                                            'TrackChangesData',
                                            'RevisionHistory',
                                            'Pagination',
                                            'WProofreader',
                                            // Careful, with the Mathtype plugin CKEditor will not load when loading this sample
                                            // from a local file system (file://) - load this site via HTTP server if you enable MathType
                                            'MathType'
                                        ]
                                    });
                                </script>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="button" class="btn btn-primary">Post</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="pt-5 px-5 col-sm-12 col-md-3 col-lg-3 text-start">
            <h5 class="text-secondary">Author</h5>
            <div class="btn-group" style="width: 75%;">
                <button class="btn btn-light btn-lg dropdown-toggle border border-3" type="button"
                    data-bs-toggle="dropdown" aria-expanded="false">
                    Pick Author
                </button>
                <ul class="dropdown-menu p-2">
                    <li><a class="dropdown-item" href="#"
                            onclick="changeText(this, 'https://www.photoshopbuzz.com/wp-content/uploads/change-color-part-of-image-psd4.jpg', 'John Ervin Engles Rola', this)">John
                            Ervin Engles Rola</a></li>
                    <li><a class="dropdown-item" href="#"
                            onclick="changeText(this, 'https://scontent.fmnl17-4.fna.fbcdn.net/v/t1.15752-9/321376570_535500711674006_452399297377209167_n.png?_nc_cat=105&amp;ccb=1-7&amp;_nc_sid=ae9488&amp;_nc_eui2=AeE6zYS3zRMZDBphTMWYhRZMW7UHGvq837BbtQca-rzfsES9JBw9ekctN6vZ-6Ch3YU0ZX4MpJ8qck3mvIXVLxol&amp;_nc_ohc=Yolpjl7IYEIAX-f27WM&amp;_nc_ht=scontent.fmnl17-4.fna&amp;oh=03_AdT5ZZaaFP8XKo8NF2ahrtJ85y4u-vtgsmbO-L7Upo8ZtA&amp;oe=645DD402', 'Rinrin Caballero', this)">Rinrin
                            Caballero</a></li>
                </ul>
            </div>
            <!-- Category dropdown menu -->
            <h5 class="text-secondary pt-4">Category</h5>
            <div class="input-group mb-3" style="width: 75%;">
                <select class="form-select" aria-label="Default select example">
                    <option selected>Open this select menu</option>
                    <option value="1">Category One</option>
                    <option value="2">Category Two</option>
                    <option value="3">Category Three</option>
                </select>
            </div>

            <!-- Tags dropdown menu -->
            <h5 class="text-secondary pt-4">Tags</h5>
            <div class="input-group mb-3" style="width: 75%;">
                <input name='input-custom-dropdown' class='some_class_name' placeholder='write some tags'
                    value='css, html, javascript'>

            </div>
        </div>

        <footer style="padding-top: 10%;">
            <div class="bg-light py-3 sticky-bottom">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6">
                            <p>&copy; 2021 My Company. All rights reserved.</p>
                        </div>
                        <div class="col-md-6 text-md-end">
                            <a href="#">Privacy Policy</a>
                            <span class="mx-2">|</span>
                            <a href="#">Terms of Service</a>
                        </div>
                    </div>
                </div>
            </div>

        </footer>
        <script src="https://cdn.jsdelivr.net/npm/@yaireo/tagify@4.3.0/dist/tagify.min.js"></script>
        <script>
            function changeText(selectedItem, imageSrc, authorName, button) {
                var authorButton = button.closest(".btn-group").querySelector(".btn");
                var newAuthorName = authorName;
                var newAuthorImageSrc = imageSrc;
                authorButton.innerHTML = '<img class="card-img-top rounded-pill" style="width: 50px;" src="' +
                    newAuthorImageSrc + '" alt="Title"> ' + newAuthorName;
            }

            

            /*tags*/
            var input = document.querySelector('input[name="input-custom-dropdown"]'),
                // init Tagify script on the above inputs
                tagify = new Tagify(input, {
                    whitelist: ["A# .NET", "A# (Axiom)", "A-0 System", "A+", "A++", "ABAP", "ABC", "ABC ALGOL", "ABSET",
                        "ABSYS", "ACC", "Accent", "Ace DASL", "ACL2", "Avicsoft", "ACT-III", "Action!", "ActionScript",
                        "Ada", "Adenine", "Agda", "Agilent VEE", "Agora", "AIMMS", "Alef", "ALF", "ALGOL 58",
                        "ALGOL 60", "ALGOL 68", "ALGOL W", "Alice", "Alma-0", "AmbientTalk", "Amiga E", "AMOS", "AMPL",
                        "Apex (Salesforce.com)", "APL", "AppleScript", "Arc", "ARexx", "Argus", "AspectJ",
                        "Assembly language", "ATS", "Ateji PX", "AutoHotkey", "Autocoder", "AutoIt",
                        "AutoLISP / Visual LISP", "Averest", "AWK", "Axum", "Active Server Pages", "ASP.NET", "B",
                        "Babbage", "Bash", "BASIC", "bc", "BCPL", "BeanShell", "Batch (Windows/Dos)", "Bertrand",
                        "BETA", "Bigwig", "Bistro", "BitC", "BLISS", "Blockly", "BlooP", "Blue", "Boo", "Boomerang",
                        "Bourne shell (including bash and ksh)", "BREW", "BPEL", "B", "C--", "C++ – ISO/IEC 14882",
                        "C# – ISO/IEC 23270", "C/AL", "Caché ObjectScript", "C Shell", "Caml", "Cayenne", "CDuce",
                        "Cecil", "Cesil", "Céu", "Ceylon", "CFEngine", "CFML", "Cg", "Ch", "Chapel", "Charity", "Charm",
                        "Chef", "CHILL", "CHIP-8", "chomski", "ChucK", "CICS", "Cilk", "Citrine (programming language)",
                        "CL (IBM)", "Claire", "Clarion", "Clean", "Clipper", "CLIPS", "CLIST", "Clojure", "CLU",
                        "CMS-2", "COBOL – ISO/IEC 1989", "CobolScript – COBOL Scripting language", "Cobra", "CODE",
                        "CoffeeScript", "ColdFusion", "COMAL", "Combined Programming Language (CPL)", "COMIT",
                        "Common Intermediate Language (CIL)", "Common Lisp (also known as CL)", "COMPASS",
                        "Component Pascal", "Constraint Handling Rules (CHR)", "COMTRAN", "Converge", "Cool", "Coq",
                        "Coral 66", "Corn", "CorVision", "COWSEL", "CPL", "CPL", "Cryptol", "csh", "Csound", "CSP",
                        "CUDA", "Curl", "Curry", "Cybil", "Cyclone", "Cython", "Java", "Javascript", "M2001", "M4",
                        "M#", "Machine code", "MAD (Michigan Algorithm Decoder)", "MAD/I", "Magik", "Magma", "make",
                        "Maple", "MAPPER now part of BIS", "MARK-IV now VISION:BUILDER", "Mary",
                        "MASM Microsoft Assembly x86", "MATH-MATIC", "Mathematica", "MATLAB",
                        "Maxima (see also Macsyma)", "Max (Max Msp – Graphical Programming Environment)", "Maya (MEL)",
                        "MDL", "Mercury", "Mesa", "Metafont", "Microcode", "MicroScript", "MIIS",
                        "Milk (programming language)", "MIMIC", "Mirah", "Miranda", "MIVA Script", "ML", "Model 204",
                        "Modelica", "Modula", "Modula-2", "Modula-3", "Mohol", "MOO", "Mortran", "Mouse", "MPD",
                        "Mathcad", "MSIL – deprecated name for CIL", "MSL", "MUMPS", "Mystic Programming L"
                    ],
                    maxTags: 10,
                    dropdown: {
                        maxItems: 20, // <- mixumum allowed rendered suggestions
                        classname: "tags-look", // <- custom classname for this dropdown, so it could be targeted
                        enabled: 0, // <- show suggestions on focus
                        closeOnSelect: false // <- do not hide the suggestions dropdown once an item has been selected
                    }
                })
        </script>
    @endsection
