{{-- @extends('layout.master1')
@section('bot')
    <div class="container-sm pb-5">
        <nav aria-label="breadcrumb" style="background: none; padding-left: 180px;">
            <ol class="breadcrumb   ">
                <li class="breadcrumb-item"><a href="help">Topics</a></li>
                <li class="breadcrumb-item"><a href="button">Sample</a></li>
                <li class="breadcrumb-item active" aria-current="page">Sample1</li>
            </ol>
        </nav>
        <div class="row">
            <div class="col-lg-2" style="padding-right: 9%;">
                <div class="list-group list-group-flush">
                    <a href="help" class="list-group-item list-group-item-action border border-0 fw-bold">Help</a>
                    <a href="page2" class="list-group-item list-group-item-action bi bi-card-text border border-0">
                        Sample</a>
                    <a href="button" class="list-group-item list-group-item-action bi bi-card-text border border-0">
                        Sample</a>
                    <a href="page2" class="list-group-item list-group-item-action bi bi-card-text border border-0">
                        Sample</a>
                    <a href="button" class="list-group-item list-group-item-action bi bi-card-text border border-0">
                        Sample</a>
                    <a href="page2" class="list-group-item list-group-item-action bi bi-card-text border border-0">
                        Sample</a>
                    <a href="button" class="list-group-item list-group-item-action bi bi-card-text border border-0">
                        Sample</a>
                </div>
            </div>
            <div class="col-lg-10 border border-secondary rounded ">
                <h1>Sample</h1>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et
                    dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip
                    ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu
                    fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia
                    deserunt mollit anim id est laborum.</p>
                <hr>
                <a href="#" class="link-dark bi bi-chat-left-text-fill"> Give feedback</a>
                <hr>
                <p>Was this helpful? <input class="btn btn-outline-secondary text-primary btn-lg" type="submit"
                        value="Yes">
                    <input class="btn btn-outline-secondary text-primary btn-lg" type="submit" value="No">
                </p>
            </div>
        </div>
    </div>
    <section id="faq" class="section pb-5" style="padding-left: 20%;">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-5 col-sm-12">
                    <div class="card sticky-element">
                        <ul class="list-group list-group-flush">
                            <h4 class="text-heading m-3">Quick Navigation</h4>
                            <a href="#"
                                class="list-group-item list-group-item-action d-flex justify-content-between align-items-center"
                                aria-current="true">
                                License
                                <i class="fas fa-chevron-right"></i>
                            </a>
                            <a href="#"
                                class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                                Pricing & Support
                                <i class="fas fa-chevron-right"></i>
                            </a>
                            <a href="#"
                                class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                                Purchasing Online
                                <i class="fas fa-chevron-right"></i>
                            </a>
                            <a href="#"
                                class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                                Returns
                                <i class="fas fa-chevron-right"></i>
                            </a>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-7 col-md-7 col-sm-5 pt-3">
                    <div class="accordion accordion-flush" id="accordionFlushExample">
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingOne">
                                <h2 class="text-heading section-heading m-3">Frequently Asked Questions</h2>
                                <p class="m-3">FAQ is suppose to be an online document that poses a series of common
                                    questions and answers on a specific topic.
                                </p>
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                    What is your refund policy and terms and conditions?
                                </button>
                            </h2>
                            <div id="collapseOne" class="accordion-collapse collapse" aria-labelledby="headingOne"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    We comply fully with KB’s refund policy. We issue refunds for the reasons KB
                                    permits us to give refund and we don’t issue refunds on the cases KB does not
                                    guarantee refunds. Please check KB’s refund policy:
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingTwo">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                    How many shortcodes/blocks/elements are there in Rogan?
                                </button>
                            </h2>
                            <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    There are over 200 shortcodes/blocks/elements in Rogan WordPress Theme. You can use
                                    any block/element into any page as you want.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingThree">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                    Is Rogan Gutenberg compatible and latest WordPress supported?
                                </button>
                            </h2>
                            <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    Yes, SaasLand is compatible with Gutenberg.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingFour">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                    How many websites can I use Rogan in with a regular license?
                                </button>
                            </h2>
                            <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    According to KB’s licensing, you can use SaasLand or any other theme on only one
                                    website. If you want to use it on multiple websites, you must buy multiple licenses.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <div class="bg-light py-3 sticky-bottom" style="margin-top: 5%;">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <p>&copy; 2021 My Company. All rights reserved.</p>
                </div>
                <div class="col-md-6 text-md-end">
                    <a href="#">Privacy Policy</a>
                    <span class="mx-2">|</span>
                    <a href="#">Terms of Service</a>
                </div>
            </div>
        </div>
    </div>
@endsection --}}
@extends('layout.master2')
@section('master')
<link rel='stylesheet' id='kbg-iconfont-css'
    href='https://demo.mekshq.com/knowledge-guru/wp-content/themes/knowledge-guru/assets/css/iconfont.css?ver=1.0.3'
    type='text/css' media='all' />
<link rel='stylesheet' id='kbg-main-css'
    href='https://demo.mekshq.com/knowledge-guru/wp-content/themes/knowledge-guru/assets/css/main-style.css?ver=1.0.3'
    type='text/css' media='all' />

    <style id='kbg-main-inline-css' type='text/css'>
        :root {
            --main-font: 'Inter', Arial, sans-serif;
            --main-font-weight: 400;
            --h-font: 'Open Sans', Arial, sans-serif;
            --h-font-weight: 600;
            --button-font: 'Inter', Arial, sans-serif;
            --button-font-weight: 700;
            --color-txt: #1D2B36;
            --color-bg: #F9F9F9;
            --color-main: #0084c2;
            --color-main-025: rgba(0, 132, 194, 0.25);
            --color-main-05: rgba(0, 132, 194, 0.5);
            --color-main-075: rgba(0, 132, 194, 0.75);
            --color-h: #1D2B36;
            --color-meta: rgba(29, 43, 54, 0.5);
            --color-header: hsl(196, 100%, 41%);
            --color-button-primary: #FECF27;
            --color-button-primary-text: #790000;
            --color-button-secondary: #0084c2;
            --color-button-tertiary: hsl(219, 60%, 95%);
            --color-txt-075: rgba(29, 43, 54, 0.75);
            --color-txt-05: rgba(29, 43, 54, 0.5);
            --color-txt-025: rgba(29, 43, 54, 0.25);
            --color-txt-015: rgba(29, 43, 54, 0.15);
            --color-txt-01: rgba(29, 43, 54, 0.1);
            --color-txt-005: rgba(29, 43, 54, 0.05);
            --color-txt-0025: rgba(29, 43, 54, 0.025);
            --color-header-middle-txt: #FFF;
            --color-header-middle-txt-05: rgba(255, 255, 255, 0.5);
            --color-header-middle-txt-075: rgba(255, 255, 255, 0.75);
            --color-header-middle-acc: var(--color-header-middle-txt-075);
            --font-size-p: 1.6rem;
            --line-height-p: 1.8;
            --font-size-small: 1.4rem;
            --line-height-small: 1.4;
            --font-size-nav: 1.4rem;
            --font-size-p-large: 1.8rem;
            --header-height: 90px;
            --header-sticky-height: 70px;
            --header-height-responsive-sm: 60px;
            --header-height-responsive-md: 80px;
            --width-full: 1102px;
            --content-post: 940px;
        }
    
        .kbg-header {
            --nav-font: 'Inter', Arial, sans-serif;
            --nav-font-weight: 700;
            font-size: 1.4rem;
        }
    
        .kbg-header {
            font-family: var(--nav-font);
            font-weight: var(--nav-font-weight);
        }
    
        .kbg-header .sub-menu {
            background: #FFF;
            color: var(--color-txt);
        }
    
        .header-main .header-middle,
        .header-mobile {
            background: hsl(196, 100%, 41%)
        }
    
        .header-main .kbg-single-subheader {
            background: var(--color-main);
        }
    
        .header-main,
        .header-main .header-middle a,
        .header-mobile a,
        .header-mobile .kbg-menu-donate li a {
            color: var(--color-header-middle-txt);
        }
    
        .header-main .sub-menu a {
            color: var(--color-txt);
        }
    
        .header-middle .sub-menu li:hover>a,
        .header-middle .sub-menu .current-menu-item>a,
        .header-middle .sub-menu .current-menu-parent>a {
            color: var(--color-header);
        }
    
        .header-middle nav>ul>li:hover>a,
        .header-middle nav>ul>.current-menu-item>a,
        .header-middle nav>ul>.current-menu-parent>a,
        .kbg-hamburger>li>a:hover,
        .kbg-hamburger>li.accordion-active>a,
        .kbg-cart>li>a:hover,
        .kbg-cart>li.accordion-active>a {
            color: var(--color-header-middle-txt-075);
        }
    
        .header-sticky {
            --color-header-sticky-bg: hsl(196, 100%, 41%);
            --color-header-sticky-txt: #FFF;
            --color-header-sticky-05: rgba(255, 255, 255, 0.5);
        }
    
        .header-sticky {
            background-color: var(--color-header-sticky-bg);
        }
    
        .header-sticky .sub-menu {
            background: #FFF;
        }
    
        .header-sticky,
        .header-sticky a,
        .header-sticky .kbg-hamburger>li>a,
        .header-sticky .kbg-cart>li>a,
        .header-sticky .kbg-cart .kbg-cart-count {
            color: var(--color-header-sticky-txt);
        }
    
        .header-sticky .sub-menu a {
            color: var(--color-txt);
        }
    
        .header-sticky .sub-menu li:hover>a,
        .header-sticky .sub-menu .current-menu-item>a,
        .header-sticky .sub-menu .current-menu-parent>a {
            color: var(--color-header-sticky-bg);
        }
    
        .header-sticky nav>ul>li:hover>a,
        .header-sticky nav>ul>.current-menu-item>a,
        .header-sticky nav>ul>.current-menu-parent>a,
        .header-sticky .kbg-hamburger>li:hover>a,
        .header-sticky .kbg-cart>li:hover>a {
            color: var(--color-header-sticky-05);
        }
    
        .header-sticky-main>.container {
            height: 70px;
        }
    
        .entry-title a {
            color: #1D2B36;
        }
    
        .entry-title a:hover,
        .fn a:hover {
            color: var(--color-main);
        }
    
        body {
            font-size: 1.6rem;
        }
    
        .widget-title {
            font-size: 2.0rem;
        }
    
        .mks_author_widget h3 {
            font-size: 1.8rem;
        }
    
        .entry-content .meks_ess_share_label h5 {
            font-size: 1.4rem;
        }
    
        .h0 {
            font-size: clamp(2.4rem, 6vw, 5.0rem);
        }
    
        h1,
        .h1 {
            font-size: clamp(2.4rem, 3vw, 3.0rem);
        }
    
        h2,
        .h2 {
            font-size: clamp(2rem, 3vw, 2.4rem);
        }
    
        h3,
        .h3 {
            font-size: clamp(2rem, 2vw, 2.0rem);
        }
    
        h4,
        .h4,
        .mks_author_widget h3,
        .wp-block-cover:not(.wp-block-kbg-search-box):not(.wp-block-kbg-contact-box) .wp-block-cover-image-text,
        .wp-block-cover:not(.wp-block-kbg-search-box):not(.wp-block-kbg-contact-box) .wp-block-cover-text,
        .wp-block-cover:not(.wp-block-kbg-search-box):not(.wp-block-kbg-contact-box) h2,
        .wp-block-cover-image:not(.wp-block-kbg-search-box):not(.wp-block-kbg-contact-box) .wp-block-cover-image-text,
        .wp-block-cover-image:not(.wp-block-kbg-search-box):not(.wp-block-kbg-contact-box) .wp-block-cover-text,
        .wp-block-cover-image:not(.wp-block-kbg-search-box):not(.wp-block-kbg-contact-box) h2 {
            font-size: clamp(1.8rem, 3vw, 1.8rem);
        }
    
        h5,
        .h5,
        .header-el-label,
        .fn,
        .wp-block-kbg-accordion-item.col-lg-4 h4 {
            font-size: clamp(1.6rem, 3vw, 1.6rem);
        }
    
        h6,
        .h6 {
            font-size: clamp(1.4rem, 3vw, 1.4rem);
        }
    
        .section-title {
            font-size: clamp(2rem, 3vw, 2.6rem);
        }
    
        .widget {
            font-size: var(--font-size-small);
        }
    
        .kbg-tax.kbg-card .entry-content {
            font-size: var(--font-size-small);
        }
    
        .paragraph-small {
            font-size: var(--font-size-small);
            font-family: var(--main-font);
        }
    
        .text-small {
            font-size: 1.2rem;
        }
    
        .text-small {
            font-family: var(--h-font);
        }
    
        .header-mobile>.container,
        .header-sticky .header-middle>.container {
            height: 60px;
        }
    
        @media (min-width: 600px) {
    
            .header-mobile>.container,
            .header-sticky .header-middle>.container {
                height: 80px;
            }
        }
    
        @media (min-width: 989px) {
            .header-main .header-middle>.container {
                height: var(--header-height);
            }
    
            .header-sticky .header-middle>.container {
                height: var(--header-sticky-height);
            }
        }
    
        .kbg-button,
        input[type="submit"],
        input[type="button"],
        button[type="submit"],
        .kbg-pagination a,
        ul.page-numbers a,
        ul.page-numbers span,
        .widget .mks_autor_link_wrap a,
        .widget .mks_read_more a,
        .paginated-post-wrapper a,
        #cancel-comment-reply-link,
        .comment-reply-link,
        .wp-block-button .wp-block-button__link {
            font-family: var(--button-font);
            font-weight: var(--button-font-weight);
        }
    
        .entry-tags a,
        .widget .tagcloud a,
        .kbg-footer .widget .tagcloud a {
            font-family: var(--h-font);
            font-weight: var(--h-font-weight);
        }
    
        .kbg-button.disabled,
        .kbg-button.disabled:hover {
            background-color: rgba(29, 43, 54, 0.1);
            color: #1D2B36;
            pointer-events: none;
        }
    
        .kbg-breadcrumbs {
            color: rgba(29, 43, 54, 0.25);
        }
    
        .kbg-breadcrumbs a {
            color: rgba(29, 43, 54, 0.5);
        }
    
        .kbg-breadcrumbs a:hover {
            color: #1D2B36;
        }
    
        .widget a {
            color: var(--color-txt);
        }
    
        .widget a:hover {
            color: var(--color-header);
        }
    
        .widget li {
            color: rgba(29, 43, 54, 0.5);
        }
    
        .kbg-sidebar ul.mks_social_widget_ul li a:hover,
        .widget_calendar #today a {
            background-color: #1D2B36;
        }
    
        .widget_calendar #today a {
            color: #fff;
        }
    
        .rssSummary,
        .widget-title .rsswidget {
            color: #1D2B36;
        }
    
        .widget_categories ul li a,
        .widget_archive ul li a {
            color: #1D2B36;
        }
    
        .kbg-header .site-title a {
            text-transform: none;
        }
    
        .site-description {
            text-transform: none;
        }
    
        .kbg-header li a {
            text-transform: uppercase;
        }
    
        .widget-title,
        .kbg-footer .widget-title {
            text-transform: none;
        }
    
        .section-title {
            text-transform: none;
        }
    
        .entry-title,
        .meks-ap-title {
            text-transform: none;
        }
    
        h1,
        h2,
        h3,
        h4,
        h5,
        h6,
        .fn,
        .h7,
        .h8 {
            text-transform: none;
        }
    
        .kbg-menu-donate li a,
        .kbg-buttons .kbg-menu-subscribe li a,
        .kbg-button,
        input[type="submit"],
        input[type="button"],
        button[type="submit"],
        .kbg-pagination a,
        ul.page-numbers a,
        ul.page-numbers .current,
        .comment-reply-link,
        #cancel-comment-reply-link,
        .meks-instagram-follow-link .meks-widget-cta,
        .mks_autor_link_wrap a,
        .mks_read_more a,
        .paginated-post-wrapper a,
        .entry-content .kbg-button,
        .kbg-subscribe .empty-list a,
        .kbg-menu-donate .empty-list a,
        .kbg-link-special,
        .kbg-button-play span,
        .entry-tags a,
        .wp-block-button__link,
        .widget .tagcloud a,
        .kbg-footer .widget .tagcloud a,
        .wp-block-tag-cloud a {
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
    
        @media(min-width: 989px) {
            .has-small-font-size {
                font-size: 1.3rem !important;
            }
    
            .has-normal-font-size {
                font-size: 1.6rem !important;
            }
    
            .has-large-font-size {
                font-size: 2.9rem !important;
            }
    
            .has-huge-font-size {
                font-size: 3.8rem !important;
            }
        }
    
        .has-kbg-main-background-color {
            background-color: #0084c2;
        }
    
        .has-kbg-main-color {
            color: #0084c2;
        }
    
        .has-kbg-text-background-color {
            background-color: #1D2B36;
        }
    
        .has-kbg-text-color {
            color: #1D2B36;
        }
    
        .has-kbg-bg-background-color {
            background-color: #F9F9F9;
        }
    
        .has-kbg-bg-color {
            color: #F9F9F9;
        }
    
        .has-kbg-h-background-color {
            background-color: #1D2B36;
        }
    
        .has-kbg-h-color {
            color: #1D2B36;
        }
    
        .has-kbg-primary-color-background-color {
            background-color: #FECF27;
        }
    
        .has-kbg-primary-color-color {
            color: #FECF27;
        }
    
        .has-kbg-primary-text-color-background-color {
            background-color: #790000;
        }
    
        .has-kbg-primary-text-color-color {
            color: #790000;
        }
    
        .kbg-footer {
            --color-footer-bg: #0084c2;
            --color-footer-txt: #FFF;
            --color-footer-txt-025: rgba(255, 255, 255, 0.25);
            --color-footer-txt-05: rgba(255, 255, 255, 0.5);
            --color-footer-txt-06: rgba(255, 255, 255, 0.6);
            background-color: var(--color-footer-bg);
            color: var(--color-footer-txt);
            font-size: 1.6rem;
        }
    
        .kbg-footer a,
        .kbg-footer .widget-title,
        .kbg-footer .widget_categories li a,
        .kbg-footer .widget_archive li a,
        .kbg-footer .widget .kbg-accordion-nav,
        .kbg-footer table,
        .kbg-footer .widget-title .rsswidget,
        .kbg-footer .widget li,
        .kbg-footer .rssSummary,
        .kbg-footer .widget p {
            color: var(--color-footer-txt);
        }
    
        .kbg-footer select {
            color: var(--color-footer-bg);
        }
    
        .kbg-footer .separator-line {
            background-color: rgba(255, 255, 255, 0.1);
        }
    
        .kbg-footer .widget li,
        .kbg-footer .rss-date {
            color: rgba(255, 255, 255, 0.5);
        }
    
        .kbg-footer .widget li a:hover,
        .kbg-footer .widget a:hover,
        .kbg-copyright a:hover {
            color: var(--color-footer-txt-06);
        }
    
        .kbg-tax-list {
            border-top: 10px solid hsl(196, 100%, 41%)
        }
    
        .alignwide {
            max-width: var(--width-full) !important;
            margin-left: auto !important;
            margin-right: auto !important;
            padding: 0 !important;
        }
    
        tr {
            border-bottom: 1px solid rgba(29, 43, 54, 0.1);
        }
    
        .wp-block-table.is-style-stripes tr:nth-child(odd) {
            background-color: rgba(29, 43, 54, 0.1);
        }
    
        body .wp-block-button .wp-block-button__link.has-background:hover {
            background-color: #1D2B36 !important;
            color: #F9F9F9;
        }
    
        .wp-block-button.is-style-outline .wp-block-button__link {
            border: 1px solid #1D2B36;
            color: #1D2B36;
        }
    
        .wp-block-button.is-style-outline .wp-block-button__link:hover {
            border: 1px solid #1D2B36;
            color: #1D2B36;
            background: 0 0;
        }
    
        .is-style-outline .wp-block-button__link {
            background: 0 0;
            color: #1D2B36;
            border: 2px solid currentcolor;
        }
    
        .wp-block-quote:before {
            background-color: rgba(29, 43, 54, 0.01);
        }
    
        .wp-block-pullquote:not(.is-style-solid-color) {
            color: #1D2B36;
            border-color: #1D2B36;
        }
    
        .wp-block-pullquote {
            background-color: #1D2B36;
            color: #F9F9F9;
        }
    
        .kbg-sidebar-none .wp-block-pullquote.alignfull.is-style-solid-color {
            box-shadow: -526px 0 0 #1D2B36, -1052px 0 0 #1D2B36, 526px 0 0 #1D2B36, 1052px 0 0 #1D2B36;
        }
    
        .entry-content>pre,
        .entry-content>code,
        .entry-content>p code,
        .comment-content>pre,
        .comment-content>code,
        .comment-content>p code {
            background-color: rgba(29, 43, 54, 0.05);
        }
    
        .wp-block-separator {
            background-color: rgba(29, 43, 54, 0.05);
        }
    
        .wp-block-rss__item-author,
        .wp-block-rss__item-publish-date {
            color: rgba(29, 43, 54, 0.5);
        }
    
        .wp-block-calendar tfoot a {
            color: rgba(29, 43, 54, 0.5);
        }
    
        .wp-block-latest-comments__comment-meta,
        .wp-block-latest-posts__post-date {
            color: rgba(29, 43, 54, 0.5);
        }
    
        @media(min-width: 600px) {}
    
        @media(min-width: 989px) {
            .size-kbg-a {
                height: 359px !important;
            }
    
            .size-kbg-a-sid {
                height: 359px !important;
            }
    
            .size-kbg-b {
                height: 316px !important;
            }
    
            .size-kbg-b-sid {
                height: 201px !important;
            }
    
            .size-kbg-tax-a {
                height: 551px !important;
            }
    
            .size-kbg-tax-b {
                height: 263px !important;
            }
    
            .size-kbg-tax-c {
                height: 201px !important;
            }
    
            .size-kbg-tax-d {
                height: 143px !important;
            }
    
            .size-kbg-tax-e {
                height: 238px !important;
            }
    
            .size-kbg-single-post-1 {
                height: 404px !important;
            }
    
            .size-kbg-single-page-1 {
                height: 404px !important;
            }
    
            .size-kbg-contact-icon {
                height: 140px !important;
            }
    
            .size-kbg-contact-image {
                height: 500px !important;
            }
        }
    
        .kbg-card,
        .kbg-button,
        form,
        .wp-block-search__button,
        input[type="text"],
        input[type="email"],
        input[type="url"],
        input[type="password"],
        input[type="search"],
        input[type="number"],
        input[type="tel"],
        textarea,
        input[type="submit"],
        input[type="button"],
        button[type="submit"],
        .kbg-pagination a,
        ul.page-numbers a,
        ul.page-numbers span,
        .page-numbers.current,
        .widget .mks_autor_link_wrap a,
        .widget .mks_read_more a,
        .paginated-post-wrapper a,
        #cancel-comment-reply-link,
        .comment-reply-link,
        .wp-block-button .wp-block-button__link,
        .kbg-contact-box,
        .kbg-contact-box.cover:after,
        .entry-tags a,
        .wp-block-quote,
        .wp-block-quote.is-style-large,
        .wp-block-quote.is-large,
        .entry-content>blockquote,
        .kbg-footer-widgets.kbg-boxed .widget,
        .search-content.kbg-boxed .wp-block-search,
        .entry-border-radius img,
        select,
        .widget .tagcloud a,
        .kbg-footer .widget .tagcloud a,
        .has-background,
        .wp-block-file,
        .wp-block-file .wp-block-file__button,
        pre,
        .wp-block-button .button__link,
        .wp-block-kbg-contact-box,
        .wp-block-tag-cloud a,
        .kbg-sidebar-right .wp-block-cover,
        .kbg-sidebar-left .wp-block-cover,
        .qa-ajax-autocomplete,
        .wp-block-search__inside-wrapper,
        .search-content.kbg-boxed .wp-block-search,
        .search-content div.wp-block-search,
        .kbg-header ul .sub-menu,
        .kbg-sidebar-right .wp-block-kbg-search-box,
        .kbg-sidebar-left .wp-block-kbg-search-box,
        .af-button,
        .widget .entry-media img,
        .af-kb-rate,
        .hamburger-sub-menu {
            border-radius: 6px !important;
        }
    
        .kbg-card .kbg-card-image img,
        .kbg-contact-box.kbg-large.kbg-image img,
        .single .kbg-content-post .entry-media img,
        .kbg-post .entry-media img,
        .kbg-content-page .entry-media img {
            border-top-left-radius: 6px;
            border-top-right-radius: 6px;
        }
    
        .kbg-contact-box.kbg-small.kbg-image img,
        .kbg-card.layout-e-image img {
            border-top-left-radius: 6px;
            border-bottom-left-radius: 6px;
            border-top-right-radius: 0;
        }
    
        .has-post-thumbnail .kbg-border-reset,
        .has-post-thumbnail.kbg-border-reset {
            border-top-left-radius: 0 !important;
            border-top-right-radius: 0 !important;
        }
    
        @media (max-width: 600px) {
            .kbg-contact-box.kbg-small.kbg-image img {
                border-radius: 6px;
            }
    
            .kbg-contact-box.kbg-small.kbg-image img,
            .kbg-card.layout-e-image img {
                border-top-left-radius: 6px;
                border-top-right-radius: 6px;
                border-bottom-left-radius: 0;
            }
        }
    </style>
<div class="kbg-section section-content mb--xxl">
    <div class="container">
        <div class="row justify-content-center">

            <div class="col-12 col-lg-4 kbg-order-3">
                <aside class="kbg-sidebar row ">


                    <div id="kbg_category_widget-4" class="widget widget_categories col-12 col-md-6 col-lg-12">
                        <div class="widget-inside kbg-card">
                            <h4 class="widget-title"> <a href="button"> Help <a></h4>
                            <ul>
                                <li><a href="button"><span
                                            class="category-text">Sample</span><span class="count">1</span></a>
                                </li>
                                <li><a href="page2"><span
                                            class="category-text">Sample</span><span class="count">2</span></a></li>
                                <li><a href="button"><span
                                            class="category-text">Sample</span><span
                                             class="count">3</span></a></li>
                                <li><a href="page2"><span
                                            class="category-text">Sample</span><span class="count">4</span></a>
                                </li>
                                <li><a href="button"><span
                                            class="category-text">Sample</span><span class="count">5</span></a>
                                </li>

                            </ul>

                        </div>
                    </div>
                </aside>
            </div>
<div class="col-12 kbg-order-1 kbg-content-height col-lg-8">
    <div class="row kbg-load-items ">
        <div class="col-12">
            <div class="kbg-card kbg-card-p kbg-border-reset">
                <div class="kbg-items">

                    <div class="item">

                        <article
                            class="kbg-post mb--xl section-item-vertical-rhythm kbg-tax-layout-a post-709 knowledge_base type-knowledge_base status-publish format-standard hentry kbg_category-getting-started kbg_category-live-chat">
                            <div class="justify-content-center">


                                <div class="entry-header d-flex">

                                    <div class="entry-header-inner">

                                        <h2 class="entry-title mb--0 mt--0 h2 kbg-content-medium"><a
                                                href="https://demo.mekshq.com/knowledge-guru/knowledge-base/pages/">Pages</a>
                                        </h2>

                                        <div class="entry-meta mt--xs">
                                            <span class="meta-item meta-date"><span class="updated">July
                                                    7,
                                                    2021</span></span>
                                        </div>


                                    </div>

                                </div>

                                <div class="entry-content mt--md">
                                    <p>Please note: This is a knowledge base article example created to help
                                        you familiarize yourself with what KnowledgeGuru can offer.
                                        KnowledgeGuru is packed with features We&#8217;ve carefully analyzed
                                        the needs of the knowledge base website owners and...</p>
                                </div>


                                <a href="https://demo.mekshq.com/knowledge-guru/knowledge-base/pages/"
                                    class="kbg-button button-tertiary button-small mt--md2">
                                    Read more </a>

                            </div>
                        </article>
                    </div>





                    <div class="item">

                        <article
                            class="kbg-post mb--xl section-item-vertical-rhythm kbg-tax-layout-a post-707 knowledge_base type-knowledge_base status-publish format-standard hentry kbg_category-getting-started kbg_category-live-chat">
                            <div class="justify-content-center">


                                <div class="entry-header d-flex">

                                    <div class="entry-header-inner">

                                        <h2 class="entry-title mb--0 mt--0 h2 kbg-content-medium"><a
                                                href="https://demo.mekshq.com/knowledge-guru/knowledge-base/modules-setup/">Modules
                                                setup</a></h2>

                                        <div class="entry-meta mt--xs">
                                            <span class="meta-item meta-date"><span class="updated">July
                                                    7, 2021</span></span>
                                        </div>


                                    </div>

                                </div>

                                <div class="entry-content mt--md">
                                    <p>Please note: This is a knowledge base article example created to help
                                        you familiarize yourself with what KnowledgeGuru can offer.
                                        KnowledgeGuru is packed with features We&#8217;ve carefully analyzed
                                        the needs of the knowledge base website owners and...</p>
                                </div>


                                <a href="https://demo.mekshq.com/knowledge-guru/knowledge-base/modules-setup/"
                                    class="kbg-button button-tertiary button-small mt--md2">
                                    Read more </a>

                            </div>
                        </article>
                    </div>





                    <div class="item">

                        <article
                            class="kbg-post mb--xl section-item-vertical-rhythm kbg-tax-layout-a post-705 knowledge_base type-knowledge_base status-publish format-standard hentry kbg_category-getting-started kbg_category-mobile_apps">
                            <div class="justify-content-center">


                                <div class="entry-header d-flex">

                                    <div class="entry-header-inner">

                                        <h2 class="entry-title mb--0 mt--0 h2 kbg-content-medium"><a
                                                href="https://demo.mekshq.com/knowledge-guru/knowledge-base/post-layouts/">Post
                                                layouts</a></h2>

                                        <div class="entry-meta mt--xs">
                                            <span class="meta-item meta-date"><span class="updated">July
                                                    7, 2021</span></span>
                                        </div>


                                    </div>

                                </div>

                                <div class="entry-content mt--md">
                                    <p>Please note: This is a knowledge base article example created to help
                                        you familiarize yourself with what KnowledgeGuru can offer.
                                        KnowledgeGuru is packed with features We&#8217;ve carefully analyzed
                                        the needs of the knowledge base website owners and...</p>
                                </div>


                                <a href="https://demo.mekshq.com/knowledge-guru/knowledge-base/post-layouts/"
                                    class="kbg-button button-tertiary button-small mt--md2">
                                    Read more </a>

                            </div>
                        </article>
                    </div>





                    <div class="item">

                        <article
                            class="kbg-post mb--xl section-item-vertical-rhythm kbg-tax-layout-a post-704 knowledge_base type-knowledge_base status-publish format-standard hentry kbg_category-getting-started kbg_category-productivity">
                            <div class="justify-content-center">


                                <div class="entry-header d-flex">

                                    <div class="entry-header-inner">

                                        <h2 class="entry-title mb--0 mt--0 h2 kbg-content-medium"><a
                                                href="https://demo.mekshq.com/knowledge-guru/knowledge-base/menu-setup/">Menu
                                                setup</a></h2>

                                        <div class="entry-meta mt--xs">
                                            <span class="meta-item meta-date"><span class="updated">July
                                                    7, 2021</span></span>
                                        </div>


                                    </div>

                                </div>

                                <div class="entry-content mt--md">
                                    <p>Please note: This is a knowledge base article example created to help
                                        you familiarize yourself with what KnowledgeGuru can offer.
                                        KnowledgeGuru is packed with features We&#8217;ve carefully analyzed
                                        the needs of the knowledge base website owners and...</p>
                                </div>


                                <a href="https://demo.mekshq.com/knowledge-guru/knowledge-base/menu-setup/"
                                    class="kbg-button button-tertiary button-small mt--md2">
                                    Read more </a>

                            </div>
                        </article>
                    </div>





                    <div class="item">

                        <article
                            class="kbg-post mb--xl section-item-vertical-rhythm kbg-tax-layout-a post-699 knowledge_base type-knowledge_base status-publish format-standard hentry kbg_category-getting-started">
                            <div class="justify-content-center">


                                <div class="entry-header d-flex">

                                    <div class="entry-header-inner">

                                        <h2 class="entry-title mb--0 mt--0 h2 kbg-content-medium"><a
                                                href="https://demo.mekshq.com/knowledge-guru/knowledge-base/installation/">Installation</a>
                                        </h2>

                                        <div class="entry-meta mt--xs">
                                            <span class="meta-item meta-date"><span class="updated">July
                                                    7, 2021</span></span>
                                        </div>


                                    </div>

                                </div>

                                <div class="entry-content mt--md">
                                    <p>Please note: This is a knowledge base article example created to help
                                        you familiarize yourself with what KnowledgeGuru can offer.
                                        KnowledgeGuru is packed with features We&#8217;ve carefully analyzed
                                        the needs of the knowledge base website owners and...</p>
                                </div>


                                <a href="https://demo.mekshq.com/knowledge-guru/knowledge-base/installation/"
                                    class="kbg-button button-tertiary button-small mt--md2">
                                    Read more </a>

                            </div>
                        </article>
                    </div>





                    <div class="item">

                        <article
                            class="kbg-post mb--xl section-item-vertical-rhythm kbg-tax-layout-a post-678 knowledge_base type-knowledge_base status-publish format-standard hentry kbg_category-getting-started">
                            <div class="justify-content-center">


                                <div class="entry-header d-flex">

                                    <div class="entry-header-inner">

                                        <h2 class="entry-title mb--0 mt--0 h2 kbg-content-medium"><a
                                                href="https://demo.mekshq.com/knowledge-guru/knowledge-base/introduction/">Introduction</a>
                                        </h2>

                                        <div class="entry-meta mt--xs">
                                            <span class="meta-item meta-date"><span class="updated">July
                                                    7, 2021</span></span>
                                        </div>


                                    </div>

                                </div>

                                <div class="entry-content mt--md">
                                    <p>Please note: This is a knowledge base article example created to help
                                        you familiarize yourself with what KnowledgeGuru can offer.
                                        KnowledgeGuru is packed with features We&#8217;ve carefully analyzed
                                        the needs of the knowledge base website owners and...</p>
                                </div>


                                <a href="https://demo.mekshq.com/knowledge-guru/knowledge-base/introduction/"
                                    class="kbg-button button-tertiary button-small mt--md2">
                                    Read more </a>

                            </div>
                        </article>
                    </div>




                </div>
                <div class="col-12 text-center kbg-order-2 kbg-pagination-main plr--0">

                    <nav class="kbg-pagination numeric-pagination prev-next">

                        <a href="javascript:void(0);" class="prev page-numbers disabled">Previous</a>


                        <nav class="navigation pagination" aria-label="Posts">
                            <h2 class="screen-reader-text">Posts navigation</h2>
                            <div class="nav-links"><span class="page-numbers current">1</span>
                                <a class="page-numbers"
                                    href="">2</a>
                                <a class="page-numbers"
                                    href="">3</a>
                                <a class="next page-numbers"
                                    href="">Next</a>
                            </div>
                        </nav>
                    </nav>
                </div>
            </div> <!-- end kbg-card -->
        </div>
    </div>
</div>
            @endsection