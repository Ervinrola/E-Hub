<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
            integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css"
            integrity="sha512-SzlrxWUlpfuzQ+pcUCosxcglQRNAq/DZjVsC0lE40xsADsfeQoEypE+enwcOiGjk/bSuGGKHEyjSoQ1zVisanQ=="
            crossorigin="anonymous" referrerpolicy="no-referrer" />
            <link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
        <link href="css/button.css" rel="stylesheet">
        {{-- <link href="css/about.css" rel="stylesheet"> --}}
        <title>eHub</title>
    </head>

<body>
    <nav class="border-bottom" style="background-color:rgb(100, 152, 229 );">
        <div class="container d-flex flex-wrap">
            <ul class="nav me-auto">
                <li class="nav-item"><a href="home"
                        class="nav-link link-dark px-2 active fa-brands fa-hubspot fa-2xl px-2 p-2 text-white"
                        aria-current="page">eHub</a></li>
                <li class="nav-item"><a href="home" class="nav-link link-dark px-2 p-1 text-white">Home</a></li>
                <li class="nav-item"><a href="community" class="nav-link link-dark px-2 p-1 text-white">Content Hive</a>
                </li>
                <li class="nav-item"><a href="about" class="nav-link link-dark px-2 p-1 text-white">About</a></li>
            </ul>
            <button type="button" class="btn btn-primary" id="assistant-btn" data-toggle="modal"><i
                    class="fas fa-comment"></i></button>
            <div class="search-bar">
                <button class="fa fa-search border-0 bg-transparent"></button>
                <input type="search" placeholder="Search Here....">
            </div>
        </div>
    </nav>
    <a href="#" class="back-to-top-btn"><i class="fa-solid fa-angle-up"></i></a>
    @yield('master')
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous">
    </script>
    <script src="js/js.js"></script>
    <script>
        window.onscroll = function() {
            scrollFunction()
        };

        function scrollFunction() {
            if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
                document.querySelector('.back-to-top-btn').style.display = "block";
            } else {
                document.querySelector('.back-to-top-btn').style.display = "none";
            }
        }

        document.querySelector('.back-to-top-btn').addEventListener('click', function(e) {
            e.preventDefault();
            document.body.scrollTop = 0;
            document.documentElement.scrollTop = 0;
        });
    </script>
</body>
</html>
