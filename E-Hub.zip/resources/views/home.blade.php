@extends('layout.master')
@section('content')
    <div class="album py-5 d-flex align-center">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-12 col-lg-8">
                    <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
                        <!-- Card 1 -->
                        <div class="col">
                            <div class="card shadow-sm">
                                <a href="help" style="text-decoration: none;">
                                    <div class="card-body">
                                        <i
                                            class="fa-solid fa-user fa-2xl mx-5 position-absolute top-50 start-0 translate-middle"></i>
                                        <p class="card-text p-5 text-dark text-center mt-3">Sample.</p>
                                    </div>
                                </a>
                            </div>
                        </div>  
                        <!-- Card 2 -->
                        <div class="col">
                            <div class="card shadow-sm">
                                <a href="help" style="text-decoration: none;">
                                    <div class="card-body">
                                        <i
                                            class="fa-solid fa-chart-column fa-2xl mx-5 position-absolute top-50 start-0 translate-middle"></i>
                                        <p class="card-text p-5 text-dark text-center mt-3">Sample.</p>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <!-- Card 3 -->
                        <div class="col">
                            <div class="card shadow-sm">
                                <a href="help" style="text-decoration: none;">
                                    <div class="card-body">
                                        <i
                                            class="fa-solid fa-chart-simple fa-2xl mx-5 position-absolute top-50 start-0 translate-middle"></i>
                                        <p class="card-text p-5 text-dark text-center mt-3">Sample.</p>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <!-- Card 4 -->
                        <div class="col">
                            <div class="card shadow-sm">
                                <a href="help" style="text-decoration: none;">
                                    <div class="card-body">
                                        <i
                                            class="fa-brands fa-github fa-2xl mx-5 position-absolute top-50 start-0 translate-middle"></i>
                                        <p class="card-text p-5 text-dark text-center mt-3">Sample.</p>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <!-- Card 5 -->
                        <div class="col">
                            <div class="card shadow-sm">
                                <a href="help" style="text-decoration: none;">
                                    <div class="card-body">
                                        <i
                                            class="fa-solid fa-users-viewfinder fa-2xl mx-5 position-absolute top-50 start-0 translate-middle"></i>
                                        <p class="card-text p-5 text-dark text-center mt-3">Sample.</p>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <!-- Card 6 -->
                        <div class="col">
                            <div class="card shadow-sm">
                                <a href="help" style="text-decoration: none;">
                                    <div class="card-body">
                                        <i
                                            class="fa-solid fa-arrow-trend-up fa-2xl mx-5 position-absolute top-50 start-0 translate-middle"></i>
                                        <p class="card-text p-5 text-dark text-center mt-3">Sample.</p>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="container pt-5 ">
                    <div class="row justify-content-md-center">
                        <div class="col-md-auto text-center">
                            <h3 class="pb-3">Can't find what you're looking for?</h3>
                            <p class="pb-3">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
                                tempor incididunt ut labore et
                                dolore magna aliqua.</p>
                            <button type="button" class="btn btn-primary w-30 p-3 rounded-pill">Contact
                                Support</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
                <!-- Footer -->
                <footer class="text-center text-lg-start bg-light text-muted p-0">
                    <!-- Section: Links  -->
                    <section class="">
                        <div class="container text-center text-md-start mt-5 p-3">
                            <!-- Grid row -->
                            <div class="row mt-3">

                                <!-- Grid column -->
                                <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">

                                    <!-- Content -->
                                    <h6 class="text-uppercase fw-bold mb-4">
                                        <i class="fas fa-gem me-3"></i>Company name
                                    </h6>
                                    <p>
                                        Here you can use rows and columns to organize your footer content. Lorem ipsum
                                        dolor sit amet, consectetur adipisicing elit.
                                    </p>
                                </div>
                                <!-- Grid column -->
                                <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
                                    <!-- Links -->
                                    <h6 class="text-uppercase fw-bold mb-4">
                                        Sample
                                    </h6>
                                    <p>
                                        <a href="#!" class="text-reset" style="text-decoration: none">Sample</a>
                                    </p>
                                    <p>
                                        <a href="#!" class="text-reset" style="text-decoration: none">Sample</a>
                                    </p>
                                    <p>
                                        <a href="#!" class="text-reset" style="text-decoration: none">Sample</a>
                                    </p>
                                    <p>
                                        <a href="#!" class="text-reset" style="text-decoration: none">Sample</a>
                                    </p>
                                </div>
                                <!-- Grid column -->
                                <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">
                                    <!-- Links -->
                                    <h6 class="text-uppercase fw-bold mb-4">
                                        Useful links
                                    </h6>
                                    <p>
                                        <a href="#!" class="text-reset" style="text-decoration: none">Sample</a>
                                    </p>
                                    <p>
                                        <a href="#!" class="text-reset" style="text-decoration: none">Sample</a>
                                    </p>
                                    <p>
                                        <a href="#!" class="text-reset" style="text-decoration: none">Sample</a>
                                    </p>
                                    <p>
                                        <a href="#!" class="text-reset" style="text-decoration: none">Sample</a>
                                    </p>
                                </div>
                                <!-- Grid column -->
                                <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
                                    <!-- Links -->
                                    <h6 class="text-uppercase fw-bold mb-4">Contact</h6>
                                    <p><i class="fas fa-home me-3"></i> Sample</p>
                                    <p>
                                        <i class="fas fa-envelope me-3"></i>
                                        info@example.com
                                    </p>
                                    <p><i class="fas fa-phone me-3"></i> + 01 234 567 88</p>
                                    <p><i class="fas fa-print me-3"></i> + 01 234 567 89</p>
                                </div>
                            </div>
                            <!-- Grid row -->
                        </div>
                    </section>
                    <hr style="height: 1px; width:80%; margin: 0 auto;">
                    <!-- Copyright -->
                    <div class="bg-light py-3 sticky-bottom">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-6">
                                    <p>&copy; 2021 My Company. All rights reserved.</p>
                                </div>
                                <div class="col-md-6 text-md-end">
                                    <a href="#">Privacy Policy</a>
                                    <span class="mx-2">|</span>
                                    <a href="#">Terms of Service</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </footer>
            @endsection
